package com.example.sharedpreferencelogin;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        new Handler().post(new Runnable(){
            @Override
            public void run(){
                SharedPreferences pref = getSharedPreferences("Login",MODE_PRIVATE);
                boolean check = pref.getBoolean("flag",false);
                Intent inext;

                if(check){
                    inext = new Intent(MainActivity.this, Home.class);
                    startActivity(inext);
                }
                else{
                    inext = new Intent(MainActivity.this, login.class);
                    startActivity(inext);
                }
            }
        });
    }
}