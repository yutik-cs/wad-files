package com.example.sign_up;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {
    private TextView txt_name,txt_email;
    private  String name;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);


        Intent intent = getIntent();

        byte[] byteArray = intent.getByteArrayExtra("image");
        Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
        name =intent.getStringExtra("name");
        String email =intent.getStringExtra("email");

        ImageView imageView = findViewById(R.id.img);
        txt_name =findViewById(R.id.name);
        txt_email =findViewById(R.id.email);

        imageView.setImageBitmap(bitmap);
        txt_name.setText(name);
        txt_email.setText(email);


    }
}