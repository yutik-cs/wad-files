package com.example.rcview;

import java.io.Serializable;

public class Person  implements Serializable {
    private String name;
    private String contact;
    private String email;
    private String age;
    private String gender;

    public Person(String name, String contact,String email, String age, String gender){
        this.name = name;
        this.contact = contact;
        this.email = email;
        this.age = age;
        this.gender = gender;
    }

    public String getName(){ return name;}
    public String getContact(){ return contact;}
    public String getEmail(){ return email;}
    public String getAge(){ return age;}
    public String getGender(){ return gender;}
}
