package com.example.rcview;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FormData extends AppCompatActivity {
    EditText name,contact,email,age;
    Button enter_btn;

    RadioGroup gender;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_form_data);
        final List<Person> list = new ArrayList<>();
        name = findViewById(R.id.nme);
        contact = findViewById(R.id.contct);
        email = findViewById(R.id.eml);
        age = findViewById(R.id.ag);
        enter_btn = findViewById(R.id.button);
        gender = findViewById(R.id.gen_grp);

        enter_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = gender.getCheckedRadioButtonId();
                if (selectedId != -1) {
                    // A RadioButton is selected
                    RadioButton selectedRadioButton = findViewById(selectedId);
                    String selectedText = selectedRadioButton.getText().toString();

                    list.add(new Person(name.getText().toString(),contact.getText().toString(),email.getText().toString(),age.getText().toString(),selectedText));
                    Intent intent = new Intent(FormData.this, MainActivity.class);
                    intent.putExtra("list", (Serializable) list);
                    startActivity(intent);

                } else {
                    // No RadioButton is selected
                    Toast.makeText(FormData.this, "No option selected", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}