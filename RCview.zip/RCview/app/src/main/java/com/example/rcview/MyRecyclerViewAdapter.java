package com.example.rcview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    private List<Person> mData;
    private LayoutInflater mInflater;

    MyRecyclerViewAdapter(Context context, List<Person> data){
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.recyclerview_row,parent,false);
        return new ViewHolder(view);
    }

//    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
//        View view = mInflater.inflate(R.layout.recyclerview_row,parent,false);
//        return new ViewHolder(view);
//    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerViewAdapter.ViewHolder holder, int position) {
        Person person = mData.get(position);
        holder.nm.setText(person.getName());
        holder.con.setText(person.getContact());
        holder.em.setText(person.getEmail());
        holder.ae.setText(person.getAge());
        holder.gen.setText(person.getGender());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView nm, con, em, ae, gen;

        ViewHolder(View itemView) {
            super(itemView);
            nm = itemView.findViewById(R.id.name);
            con = itemView.findViewById(R.id.contact);
            em = itemView.findViewById(R.id.email);
            ae = itemView.findViewById(R.id.age);
            gen = itemView.findViewById(R.id.gender);
        }
    }
}
