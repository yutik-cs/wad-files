package com.example.contextmenu;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    LinearLayout main;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.txtV);
        main = findViewById(R.id.main);
        registerForContextMenu(tv);

    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){
        super.onCreateContextMenu(menu,view,menuInfo);
        menu.setHeaderTitle("Choose a color:");
        menu.add(0,view.getId(),0,"Light Yellow");
        menu.add(0,view.getId(),0,"Purple");
        menu.add(0,view.getId(),0,"Green");
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item){
        if(item.getTitle() == "Light Yellow"){
            main.setBackgroundColor(Color.argb(100, 225, 193, 7));
        }
        if(item.getTitle() == "Purple"){
            main.setBackgroundColor(Color.argb(100, 89, 64, 187));
        }
        if(item.getTitle() == "Green"){
            main.setBackgroundColor(Color.argb(100, 3, 209, 111));
        }
        return true;
    }
}